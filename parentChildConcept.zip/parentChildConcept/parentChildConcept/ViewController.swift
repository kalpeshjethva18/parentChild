//
//  ViewController.swift
//  mycontrols
//
//  Created by jayesh on 2/27/17.
//  Copyright © 2017 jayesh. All rights reserved.
//

import UIKit



class ViewController: UIViewController {

    @IBOutlet weak var btnRemove: UIButton!
    
    var counter = NSInteger()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func childview(_ sender: UIButton) {
        
        let childe : childViewController = childViewController (nibName: "childViewController", bundle: nil)
        self.addChildViewController(childe)
        self.view.addSubview(childe.view)
        childe.didMove(toParentViewController: self)
    }
    
    func hideContentController(content: UIViewController) {
        content.willMove(toParentViewController: nil)
        content.view.removeFromSuperview()
        content.removeFromParentViewController()
    }
    @IBAction func btnRemoveAction(_ sender: UIButton) {
        
        if counter == 0
        {
            counter = 1
            objkjFunction.showLoader(myview: self.view)
            self.view.addSubview(btnRemove)
        }
        else{
            counter = 0
            objkjFunction.RemoveLoader(myview: self.view)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

