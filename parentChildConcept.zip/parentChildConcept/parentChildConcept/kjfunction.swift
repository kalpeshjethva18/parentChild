//
//  kjfunction.swift
//  mycontrols
//
//  Created by jayesh on 2/27/17.
//  Copyright © 2017 jayesh. All rights reserved.
//

import UIKit

var objkjFunction = kjfunction()

class kjfunction: NSObject {
    
    func showLoader(myview: UIView)
   {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let aVariable = appDelegate.loaderView
   
        aVariable?.frame = myview.frame
        let subview = appDelegate.subLoader
        subview?.layer.cornerRadius = 10.0
        subview?.layer.masksToBounds = true
        let actloader = appDelegate.actLoader
        actloader?.startAnimating()
        myview.addSubview(aVariable!)
    }
    func RemoveLoader(myview: UIView)
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let aVariable = appDelegate.loaderView
        aVariable?.removeFromSuperview()
    }
}
